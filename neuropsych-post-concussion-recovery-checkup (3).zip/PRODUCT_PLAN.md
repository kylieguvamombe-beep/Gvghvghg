# Neuropsych Post-Concussion Recovery Checkup - MVP Product Plan

## 1. App Overview
**Name:** Neuropsych Post-Concussion Recovery Checkup  
**Purpose:** A structured, clinically informed follow-up tool for post-concussion recovery. It helps users track symptoms, cognitive changes, emotional state, physical complaints, and functional recovery over time. It is not a diagnostic tool or a replacement for medical care, but a supportive monitoring system that highlights warning signs and generates actionable data for clinical review.  
**Tone:** Calm, clear, supportive, professional, and reassuring.  
**Aesthetic:** Modern medical. Soft colors (teals, soft blues, warm grays), strong readability, clean cards, progress bars, and simple icons.

## 2. User Roles
**Patient / Caregiver:**
- **Goal:** Track recovery progress, understand symptoms, and know when to seek help.
- **Experience:** Guided, low-stress, one-question-at-a-time check-ups. Clear visual feedback on progress.

**Clinician / Trainee / Supervisor:**
- **Goal:** Review patient-reported data efficiently, identify trends, and document clinical observations.
- **Experience:** Data-dense dashboard, trend graphs, summary cards, comparison views, and exportable reports.

## 3. Screen-by-Screen Structure
1. **Welcome Screen:** Secure login, privacy consent, and role selection (Patient vs. Clinician).
2. **Onboarding Flow (Patient):** Collects age range, date of injury, cause, prior concussions, medications, and diagnosis status.
3. **Patient Dashboard:** Shows next scheduled check-in, recent recovery category, and a simple trend chart.
4. **Symptom Baseline / Check-up Flow:**
   - **Physical:** Headache, dizziness, nausea, light/noise sensitivity, sleep, fatigue, balance.
   - **Cognitive:** Memory, attention, processing speed, word finding, mental fatigue.
   - **Mood & Behavior:** Frustration, low mood, emotional lability, anxiety, withdrawal.
   - **Functional:** Return to school/work, exercise, driving, reading, screen time.
5. **Red-Flag Alert Page:** Triggered by severe symptoms (e.g., worsening headache, repeated vomiting). Recommends urgent medical care.
6. **Recovery Summary:** End of check-up. Categorizes status (Improving, Stable, Delayed Recovery, Needs Medical Review).
7. **Clinician Dashboard:** List of patients with high-level status alerts.
8. **Clinician Patient Detail:** Trend graphs, summary cards, comparison across visits.
9. **Clinician Notes:** Section for observations, recommendations, follow-up intervals, and referrals.
10. **Exportable Report:** Printable/downloadable PDF summary of patient details, trends, and clinical notes.

## 4. Data Fields and Logic
**Patient Profile:**
- `id`, `name`, `ageRange`, `dateOfInjury`, `causeOfInjury`, `diagnosedByClinician`, `medications`, `priorConcussions`, `role`

**Check-up Data (0-5 or 0-10 scales):**
- **Physical:** `headache`, `dizziness`, `nausea`, `lightSensitivity`, `noiseSensitivity`, `fatigue`, `balance`
- **Cognitive:** `memory`, `attention`, `processingSpeed`, `wordFinding`, `mentalFatigue`
- **Mood:** `frustration`, `lowMood`, `anxiety`, `sleepDisruption`
- **Functional:** `schoolWork`, `exercise`, `screenTolerance`
- **Red Flags:** `worseningHeadache`, `repeatedVomiting`, `seizures`, `fainting`, `newConfusion`, `severeImbalance`, `suicidalThinking`

**Logic:**
- **Red Flag Trigger:** If any red flag is `true` -> Show Red-Flag Alert Page.
- **Recovery Category:** 
  - *Improving:* Overall symptom score decreasing over last 3 check-ups.
  - *Stable:* Score remains within a narrow margin.
  - *Delayed Recovery:* Score remains high after 4 weeks.
  - *Needs Medical Review:* Score increasing or red flags present.

## 5. Suggested MVP Build Plan
**Tech Stack:**
- **Frontend:** React (Vite) / Tailwind CSS / Framer Motion (for smooth transitions) / Recharts (for data visualization).
- **State Management:** Zustand (for local prototype state).
- **Export:** jsPDF / html2canvas.
- **Backend (Future):** Firebase or Supabase for secure, HIPAA-compliant data storage and authentication.

**Development Phases:**
1. **Phase 1 (Prototype):** Build UI components, navigation, and state management. Implement Patient Check-up flow and Clinician Dashboard with mock data.
2. **Phase 2 (Logic & Charts):** Add scoring logic, red-flag triggers, and Recharts for trend visualization.
3. **Phase 3 (Export & Polish):** Implement PDF export, refine animations, and ensure responsive design.

---

## Sample Text

**Onboarding Consent:**
> "Welcome to the Neuropsych Post-Concussion Recovery Checkup. This app is designed to help you and your healthcare team track your recovery over time. Please note: This tool does not replace a doctor, diagnose concussions, or provide emergency care. Your health data is stored securely and handled with care. Do you consent to proceed?"

**Safety Alert (Red Flag):**
> "⚠️ **Urgent Medical Attention Recommended**  
> You reported symptoms that require immediate medical review (e.g., worsening headache, repeated vomiting, or new confusion). Please contact your doctor, visit an urgent care clinic, or go to the nearest emergency room immediately. Do not wait."

**Recovery Summary (Patient):**
> "Thank you for completing your check-in. Based on your recent logs, your symptoms appear to be **Improving**. Your cognitive fatigue has decreased, and your physical symptoms are stable. Keep following your gradual return-to-activity plan. Your next check-in is scheduled in 3 days."

**Clinician Note Template:**
> **Clinical Observations:** Patient presents with stable physical symptoms but reports ongoing cognitive fatigue during screen time.  
> **Recommendations:** Implement 20-20-20 rule for screen use. Limit continuous reading to 15-minute intervals.  
> **Follow-up Interval:** 1 week.  
> **Referrals Indicated:** Vestibular Therapy (Pending).
