import { create } from 'zustand';

export type Role = 'patient' | 'clinician' | null;

export interface PatientProfile {
  id: string;
  name: string;
  ageRange: string;
  dateOfInjury: string;
  causeOfInjury: string;
  diagnosedByClinician: boolean;
  medications: string;
  priorConcussions: string;
}

export interface Checkup {
  id: string;
  patientId: string;
  date: string;
  
  // Physical (0-5)
  headache: number;
  dizziness: number;
  nausea: number;
  lightSensitivity: number;
  noiseSensitivity: number;
  sleepChanges: number;
  fatigue: number;
  balance: number;

  // Cognitive (0-5)
  memory: number;
  attention: number;
  processingSpeed: number;
  wordFinding: number;
  mentalFatigue: number;

  // Mood (0-5)
  frustration: number;
  lowMood: number;
  anxiety: number;
  irritability: number;
  withdrawal: number;

  // Functional (boolean or 0-5)
  schoolWork: number;
  exercise: number;
  driving: number;
  reading: number;
  screenTime: number;
  socialActivity: number;

  // Red Flags (boolean)
  worseningHeadache: boolean;
  repeatedVomiting: boolean;
  seizures: boolean;
  fainting: boolean;
  newConfusion: boolean;
  severeImbalance: boolean;
  suicidalThinking: boolean;

  // Derived
  recoveryCategory: 'Improving' | 'Stable' | 'Delayed Recovery' | 'Needs Medical Review';
}

export interface ClinicianNote {
  id: string;
  patientId: string;
  date: string;
  observations: string;
  recommendations: string;
  followUpInterval: string;
  referrals: string;
}

interface AppState {
  role: Role;
  setRole: (role: Role) => void;
  
  patientProfile: PatientProfile | null;
  setPatientProfile: (profile: PatientProfile) => void;
  
  checkups: Checkup[];
  addCheckup: (checkup: Checkup) => void;

  clinicianNotes: ClinicianNote[];
  addClinicianNote: (note: ClinicianNote) => void;

  // Mock data for clinician view
  mockPatients: PatientProfile[];
}

const mockPatients: PatientProfile[] = [
  {
    id: 'p1',
    name: 'Alex Johnson',
    ageRange: '25-34',
    dateOfInjury: '2023-09-15',
    causeOfInjury: 'Sports',
    diagnosedByClinician: true,
    medications: 'Ibuprofen as needed',
    priorConcussions: '1',
  },
  {
    id: 'p2',
    name: 'Sarah Smith',
    ageRange: '18-24',
    dateOfInjury: '2023-10-02',
    causeOfInjury: 'Fall',
    diagnosedByClinician: true,
    medications: 'None',
    priorConcussions: '0',
  }
];

const mockCheckups: Checkup[] = [
  {
    id: 'c1',
    patientId: 'p1',
    date: '2023-09-20',
    headache: 4, dizziness: 3, nausea: 1, lightSensitivity: 4, noiseSensitivity: 3, sleepChanges: 4, fatigue: 5, balance: 2,
    memory: 3, attention: 4, processingSpeed: 3, wordFinding: 2, mentalFatigue: 4,
    frustration: 3, lowMood: 2, anxiety: 3, irritability: 4, withdrawal: 2,
    schoolWork: 5, exercise: 5, driving: 5, reading: 4, screenTime: 5, socialActivity: 3,
    worseningHeadache: false, repeatedVomiting: false, seizures: false, fainting: false, newConfusion: false, severeImbalance: false, suicidalThinking: false,
    recoveryCategory: 'Stable'
  },
  {
    id: 'c2',
    patientId: 'p1',
    date: '2023-09-27',
    headache: 2, dizziness: 1, nausea: 0, lightSensitivity: 2, noiseSensitivity: 1, sleepChanges: 2, fatigue: 3, balance: 0,
    memory: 1, attention: 2, processingSpeed: 1, wordFinding: 1, mentalFatigue: 2,
    frustration: 1, lowMood: 1, anxiety: 1, irritability: 2, withdrawal: 1,
    schoolWork: 3, exercise: 4, driving: 2, reading: 2, screenTime: 3, socialActivity: 1,
    worseningHeadache: false, repeatedVomiting: false, seizures: false, fainting: false, newConfusion: false, severeImbalance: false, suicidalThinking: false,
    recoveryCategory: 'Improving'
  }
];

export const useStore = create<AppState>((set) => ({
  role: null,
  setRole: (role) => set({ role }),
  
  patientProfile: mockPatients[0],
  setPatientProfile: (profile) => set({ patientProfile: profile }),
  
  checkups: mockCheckups,
  addCheckup: (checkup) => set((state) => ({ checkups: [...state.checkups, checkup] })),

  clinicianNotes: [],
  addClinicianNote: (note) => set((state) => ({ clinicianNotes: [...state.clinicianNotes, note] })),

  mockPatients,
}));
