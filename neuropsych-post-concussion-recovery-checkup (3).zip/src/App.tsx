/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useStore } from './store/useStore';
import Welcome from './pages/Welcome';
import Onboarding from './pages/Onboarding';
import PatientDashboard from './pages/PatientDashboard';
import CheckupFlow from './pages/CheckupFlow';
import RedFlagAlert from './pages/RedFlagAlert';
import RecoverySummary from './pages/RecoverySummary';
import ClinicianDashboard from './pages/ClinicianDashboard';
import ClinicianPatientDetail from './pages/ClinicianPatientDetail';

export default function App() {
  const role = useStore((state) => state.role);

  return (
    <Router>
      <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-teal-200">
        <Routes>
          <Route path="/" element={<Welcome />} />
          <Route path="/onboarding" element={<Onboarding />} />
          
          {/* Patient Routes */}
          <Route path="/patient/dashboard" element={<PatientDashboard />} />
          <Route path="/patient/checkup" element={<CheckupFlow />} />
          <Route path="/patient/red-flag" element={<RedFlagAlert />} />
          <Route path="/patient/summary" element={<RecoverySummary />} />

          {/* Clinician Routes */}
          <Route path="/clinician/dashboard" element={<ClinicianDashboard />} />
          <Route path="/clinician/patient/:id" element={<ClinicianPatientDetail />} />
          
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    </Router>
  );
}
