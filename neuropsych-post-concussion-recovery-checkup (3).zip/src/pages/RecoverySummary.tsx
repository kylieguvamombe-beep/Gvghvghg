import { useLocation, useNavigate } from 'react-router-dom';
import { useStore } from '../store/useStore';
import { CheckCircle2, Calendar, Activity, ArrowRight } from 'lucide-react';

export default function RecoverySummary() {
  const location = useLocation();
  const navigate = useNavigate();
  const profile = useStore((state) => state.patientProfile);
  
  const category = location.state?.category || 'Stable';
  
  const getCategoryColor = (cat: string) => {
    switch (cat) {
      case 'Improving': return 'text-emerald-600 bg-emerald-50 border-emerald-200';
      case 'Stable': return 'text-blue-600 bg-blue-50 border-blue-200';
      case 'Delayed Recovery': return 'text-amber-600 bg-amber-50 border-amber-200';
      case 'Needs Medical Review': return 'text-rose-600 bg-rose-50 border-rose-200';
      default: return 'text-slate-600 bg-slate-50 border-slate-200';
    }
  };

  const getCategoryMessage = (cat: string) => {
    switch (cat) {
      case 'Improving': return 'Your symptoms appear to be decreasing. Keep following your gradual return-to-activity plan.';
      case 'Stable': return 'Your symptoms are stable. Continue to monitor and rest as needed.';
      case 'Delayed Recovery': return 'Your symptoms remain elevated. Consider discussing this with your healthcare provider at your next visit.';
      case 'Needs Medical Review': return 'You reported symptoms that may require medical attention. Please contact your doctor.';
      default: return 'Thank you for completing your check-up.';
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6">
      <div className="max-w-md w-full bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-100">
        <div className="p-8 text-center">
          <div className="w-20 h-20 bg-teal-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="w-10 h-10 text-teal-600" />
          </div>
          <h1 className="text-2xl font-semibold text-slate-900 mb-2">Check-up Complete</h1>
          <p className="text-slate-500 text-sm">Thank you for logging your symptoms, {profile?.name || 'Friend'}.</p>
        </div>
        
        <div className="p-8 pt-0 space-y-6">
          <div className={`p-6 rounded-2xl border ${getCategoryColor(category)} relative overflow-hidden`}>
            <div className="absolute top-0 right-0 w-24 h-24 bg-white/20 rounded-full -mr-12 -mt-12"></div>
            <div className="flex items-center space-x-2 mb-2 relative z-10">
              <Activity className="w-5 h-5 opacity-80" />
              <h2 className="font-semibold uppercase tracking-wider text-xs opacity-80">Current Status</h2>
            </div>
            <div className="text-2xl font-bold mb-3 relative z-10">{category}</div>
            <p className="text-sm font-medium opacity-90 relative z-10 leading-relaxed">
              {getCategoryMessage(category)}
            </p>
          </div>

          <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100">
            <div className="flex items-center text-slate-600">
              <Calendar className="w-5 h-5 mr-3 text-slate-400" />
              <span className="text-sm font-medium">Next Check-in</span>
            </div>
            <span className="text-sm font-semibold text-slate-900">In 3 days</span>
          </div>

          <button
            onClick={() => navigate('/patient/dashboard')}
            className="w-full bg-teal-600 hover:bg-teal-700 text-white font-medium py-4 px-6 rounded-2xl flex items-center justify-center transition-colors shadow-sm mt-8"
          >
            Return to Dashboard
            <ArrowRight className="w-5 h-5 ml-2" />
          </button>
        </div>
      </div>
    </div>
  );
}
