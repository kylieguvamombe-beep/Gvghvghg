import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useStore, ClinicianNote } from '../store/useStore';
import { ArrowLeft, Download, FileText, Activity, Brain, Heart, Calendar, Plus, GitCompare } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

export default function ClinicianPatientDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const patient = useStore((state) => state.mockPatients.find(p => p.id === id));
  const checkups = useStore((state) => state.checkups).filter(c => c.patientId === id);
  const notes = useStore((state) => state.clinicianNotes).filter(n => n.patientId === id);
  const addClinicianNote = useStore((state) => state.addClinicianNote);

  const [activeTab, setActiveTab] = useState<'overview' | 'trends' | 'comparison' | 'notes'>('overview');
  const [showNoteModal, setShowNoteModal] = useState(false);
  const [compareCheckup1, setCompareCheckup1] = useState<string | null>(checkups.length >= 2 ? checkups[checkups.length - 2].id : (checkups.length > 0 ? checkups[0].id : null));
  const [compareCheckup2, setCompareCheckup2] = useState<string | null>(checkups.length > 0 ? checkups[checkups.length - 1].id : null);
  const [newNote, setNewNote] = useState<Partial<ClinicianNote>>({
    observations: '',
    recommendations: '',
    followUpInterval: '1 week',
    referrals: 'None'
  });

  if (!patient) return <div className="p-8 text-center text-slate-500">Patient not found</div>;

  const latestCheckup = checkups.length > 0 ? checkups[checkups.length - 1] : null;

  const chartData = checkups.map(c => ({
    date: new Date(c.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    physical: (c.headache + c.dizziness + c.nausea + c.lightSensitivity + c.noiseSensitivity + c.fatigue + c.balance) / 7,
    cognitive: (c.memory + c.attention + c.processingSpeed + c.wordFinding + c.mentalFatigue) / 5,
    mood: (c.frustration + c.lowMood + c.anxiety + c.irritability + c.withdrawal) / 5,
  }));

  const handleSaveNote = () => {
    addClinicianNote({
      id: `n_${Date.now()}`,
      patientId: patient.id,
      date: new Date().toISOString(),
      observations: newNote.observations || '',
      recommendations: newNote.recommendations || '',
      followUpInterval: newNote.followUpInterval || '',
      referrals: newNote.referrals || ''
    });
    setShowNoteModal(false);
    setNewNote({ observations: '', recommendations: '', followUpInterval: '1 week', referrals: 'None' });
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-20 shadow-sm">
        <div className="flex items-center justify-between p-4 max-w-3xl mx-auto">
          <div className="flex items-center">
            <button onClick={() => navigate('/clinician/dashboard')} className="p-2 -ml-2 mr-2 text-slate-500 hover:text-slate-800 transition-colors rounded-full hover:bg-slate-100">
              <ArrowLeft className="w-6 h-6" />
            </button>
            <div>
              <h1 className="text-lg font-semibold text-slate-900">{patient.name}</h1>
              <p className="text-xs text-slate-500">ID: {patient.id.toUpperCase()}</p>
            </div>
          </div>
          <button className="p-2 text-blue-600 hover:bg-blue-50 rounded-full transition-colors flex items-center">
            <Download className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex px-4 max-w-3xl mx-auto space-x-6 border-t border-slate-100 overflow-x-auto">
          {(['overview', 'trends', 'comparison', 'notes'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`py-4 text-sm font-medium capitalize border-b-2 transition-colors whitespace-nowrap ${
                activeTab === tab 
                  ? 'border-blue-600 text-blue-600' 
                  : 'border-transparent text-slate-500 hover:text-slate-700'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 p-6 max-w-3xl mx-auto w-full space-y-6">
        {activeTab === 'overview' && (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {/* Patient Info Card */}
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
              <h2 className="text-lg font-semibold text-slate-900 mb-4 flex items-center">
                <User className="w-5 h-5 mr-2 text-slate-400" />
                Patient Profile
              </h2>
              <div className="grid grid-cols-2 gap-y-4 gap-x-6 text-sm">
                <div>
                  <span className="block text-slate-500 mb-1">Age Range</span>
                  <span className="font-medium text-slate-900">{patient.ageRange}</span>
                </div>
                <div>
                  <span className="block text-slate-500 mb-1">Date of Injury</span>
                  <span className="font-medium text-slate-900">{new Date(patient.dateOfInjury).toLocaleDateString()}</span>
                </div>
                <div>
                  <span className="block text-slate-500 mb-1">Cause</span>
                  <span className="font-medium text-slate-900">{patient.causeOfInjury}</span>
                </div>
                <div>
                  <span className="block text-slate-500 mb-1">Prior Concussions</span>
                  <span className="font-medium text-slate-900">{patient.priorConcussions}</span>
                </div>
                <div className="col-span-2">
                  <span className="block text-slate-500 mb-1">Medications</span>
                  <span className="font-medium text-slate-900">{patient.medications || 'None reported'}</span>
                </div>
              </div>
            </div>

            {/* Latest Status */}
            {latestCheckup && (
              <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-lg font-semibold text-slate-900 flex items-center">
                    <Activity className="w-5 h-5 mr-2 text-blue-500" />
                    Latest Check-up
                  </h2>
                  <span className="text-xs font-medium bg-slate-100 text-slate-600 px-3 py-1 rounded-full">
                    {new Date(latestCheckup.date).toLocaleDateString()}
                  </span>
                </div>

                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 mb-6">
                  <span className="text-sm text-slate-500 block mb-1">Recovery Category</span>
                  <span className="text-lg font-semibold text-slate-900">{latestCheckup.recoveryCategory}</span>
                </div>

                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-slate-600 font-medium">Physical Symptoms</span>
                      <span className="text-slate-900 font-semibold">{latestCheckup.headache}/5</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div className="bg-sky-500 h-full" style={{ width: `${(latestCheckup.headache / 5) * 100}%` }} />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-slate-600 font-medium">Cognitive Fatigue</span>
                      <span className="text-slate-900 font-semibold">{latestCheckup.mentalFatigue}/5</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div className="bg-amber-500 h-full" style={{ width: `${(latestCheckup.mentalFatigue / 5) * 100}%` }} />
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'trends' && (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
              <h2 className="text-lg font-semibold text-slate-900 mb-6 flex items-center">
                <Activity className="w-5 h-5 mr-2 text-blue-500" />
                Longitudinal Recovery Trends
              </h2>
              
              {checkups.length > 0 ? (
                <div className="h-80 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData} margin={{ top: 5, right: 20, left: -20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} dy={10} />
                      <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} domain={[0, 5]} />
                      <Tooltip 
                        contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                        labelStyle={{ color: '#64748b', marginBottom: '4px', fontWeight: 600 }}
                      />
                      <Legend verticalAlign="top" height={36} iconType="circle" wrapperStyle={{ fontSize: '12px', color: '#64748b' }}/>
                      <Line type="monotone" dataKey="physical" name="Physical" stroke="#0ea5e9" strokeWidth={3} dot={{ r: 4, strokeWidth: 2 }} activeDot={{ r: 6 }} />
                      <Line type="monotone" dataKey="cognitive" name="Cognitive" stroke="#f59e0b" strokeWidth={3} dot={{ r: 4, strokeWidth: 2 }} activeDot={{ r: 6 }} />
                      <Line type="monotone" dataKey="mood" name="Mood/Behavior" stroke="#8b5cf6" strokeWidth={3} dot={{ r: 4, strokeWidth: 2 }} activeDot={{ r: 6 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <div className="text-center py-12 text-slate-500 bg-slate-50 rounded-2xl border border-slate-100 border-dashed">
                  Not enough data to display trends.
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'comparison' && (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
              <h2 className="text-lg font-semibold text-slate-900 mb-6 flex items-center">
                <GitCompare className="w-5 h-5 mr-2 text-blue-500" />
                Compare Check-ups
              </h2>

              {checkups.length < 2 ? (
                <div className="text-center py-12 text-slate-500 bg-slate-50 rounded-2xl border border-slate-100 border-dashed">
                  Need at least two check-ups to compare.
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Baseline / Earlier</label>
                      <select 
                        value={compareCheckup1 || ''}
                        onChange={(e) => setCompareCheckup1(e.target.value)}
                        className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all bg-white text-sm"
                      >
                        {checkups.map((c, idx) => (
                          <option key={c.id} value={c.id}>
                            {new Date(c.date).toLocaleDateString()} (Check-up {idx + 1})
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Follow-up / Later</label>
                      <select 
                        value={compareCheckup2 || ''}
                        onChange={(e) => setCompareCheckup2(e.target.value)}
                        className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all bg-white text-sm"
                      >
                        {checkups.map((c, idx) => (
                          <option key={c.id} value={c.id}>
                            {new Date(c.date).toLocaleDateString()} (Check-up {idx + 1})
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {(() => {
                    const c1 = checkups.find(c => c.id === compareCheckup1);
                    const c2 = checkups.find(c => c.id === compareCheckup2);

                    if (!c1 || !c2) return null;

                    const c1Physical = (c1.headache + c1.dizziness + c1.nausea + c1.lightSensitivity + c1.noiseSensitivity + c1.fatigue + c1.balance) / 7;
                    const c2Physical = (c2.headache + c2.dizziness + c2.nausea + c2.lightSensitivity + c2.noiseSensitivity + c2.fatigue + c2.balance) / 7;

                    const c1Cognitive = (c1.memory + c1.attention + c1.processingSpeed + c1.wordFinding + c1.mentalFatigue) / 5;
                    const c2Cognitive = (c2.memory + c2.attention + c2.processingSpeed + c2.wordFinding + c2.mentalFatigue) / 5;

                    const c1Mood = (c1.frustration + c1.lowMood + c1.anxiety + c1.irritability + c1.withdrawal) / 5;
                    const c2Mood = (c2.frustration + c2.lowMood + c2.anxiety + c2.irritability + c2.withdrawal) / 5;

                    const comparisonData = [
                      {
                        category: 'Physical',
                        Earlier: parseFloat(c1Physical.toFixed(1)),
                        Later: parseFloat(c2Physical.toFixed(1)),
                      },
                      {
                        category: 'Cognitive',
                        Earlier: parseFloat(c1Cognitive.toFixed(1)),
                        Later: parseFloat(c2Cognitive.toFixed(1)),
                      },
                      {
                        category: 'Mood',
                        Earlier: parseFloat(c1Mood.toFixed(1)),
                        Later: parseFloat(c2Mood.toFixed(1)),
                      }
                    ];

                    const getChangeColor = (val1: number, val2: number) => {
                      if (val2 < val1) return 'text-emerald-600'; // Improved (lower score)
                      if (val2 > val1) return 'text-rose-600'; // Worsened
                      return 'text-slate-500'; // No change
                    };

                    const getChangeText = (val1: number, val2: number) => {
                      const diff = val2 - val1;
                      if (diff === 0) return 'No change';
                      return `${diff > 0 ? '+' : ''}${diff.toFixed(1)}`;
                    };

                    return (
                      <div className="space-y-8">
                        <div className="h-64 w-full mt-6">
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={comparisonData} margin={{ top: 20, right: 0, left: -20, bottom: 0 }}>
                              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                              <XAxis dataKey="category" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} dy={10} />
                              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} domain={[0, 5]} />
                              <Tooltip 
                                cursor={{ fill: '#f8fafc' }}
                                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                              />
                              <Legend verticalAlign="top" height={36} iconType="circle" wrapperStyle={{ fontSize: '12px', color: '#64748b' }}/>
                              <Bar dataKey="Earlier" fill="#94a3b8" radius={[4, 4, 0, 0]} barSize={30} />
                              <Bar dataKey="Later" fill="#3b82f6" radius={[4, 4, 0, 0]} barSize={30} />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>

                        <div className="grid grid-cols-3 gap-4">
                          {comparisonData.map(d => (
                            <div key={d.category} className="bg-slate-50 p-4 rounded-2xl border border-slate-100 text-center">
                              <div className="text-sm font-medium text-slate-500 mb-2">{d.category}</div>
                              <div className="flex justify-center items-center space-x-3">
                                <span className="text-slate-400 font-medium">{d.Earlier}</span>
                                <ArrowLeft className="w-4 h-4 text-slate-300 rotate-180" />
                                <span className="text-slate-900 font-semibold">{d.Later}</span>
                              </div>
                              <div className={`text-xs font-medium mt-2 ${getChangeColor(d.Earlier, d.Later)}`}>
                                {getChangeText(d.Earlier, d.Later)}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })()}
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'notes' && (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="flex justify-between items-center">
              <h2 className="text-lg font-semibold text-slate-900">Clinical Notes</h2>
              <button 
                onClick={() => setShowNoteModal(true)}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-sm font-medium transition-colors shadow-sm flex items-center"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Note
              </button>
            </div>

            {notes.length === 0 ? (
              <div className="text-center py-12 text-slate-500 bg-white rounded-3xl border border-slate-100 border-dashed shadow-sm">
                <FileText className="w-10 h-10 mx-auto text-slate-300 mb-3" />
                <p>No clinical notes recorded yet.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {notes.slice().reverse().map(note => (
                  <div key={note.id} className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
                    <div className="flex items-center text-xs text-slate-500 mb-4 font-medium uppercase tracking-wider">
                      <Calendar className="w-4 h-4 mr-2" />
                      {new Date(note.date).toLocaleDateString()} at {new Date(note.date).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                    </div>
                    
                    <div className="space-y-4 text-sm">
                      <div>
                        <span className="block font-semibold text-slate-900 mb-1">Observations</span>
                        <p className="text-slate-700 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">{note.observations}</p>
                      </div>
                      <div>
                        <span className="block font-semibold text-slate-900 mb-1">Recommendations</span>
                        <p className="text-slate-700 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">{note.recommendations}</p>
                      </div>
                      <div className="grid grid-cols-2 gap-4 pt-2">
                        <div>
                          <span className="block font-semibold text-slate-900 mb-1">Follow-up</span>
                          <span className="text-slate-700">{note.followUpInterval}</span>
                        </div>
                        <div>
                          <span className="block font-semibold text-slate-900 mb-1">Referrals</span>
                          <span className="text-slate-700">{note.referrals}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Note Modal */}
      {showNoteModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <h3 className="text-lg font-semibold text-slate-900">New Clinical Note</h3>
              <button onClick={() => setShowNoteModal(false)} className="text-slate-400 hover:text-slate-600">
                &times;
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Observations</label>
                <textarea 
                  value={newNote.observations}
                  onChange={(e) => setNewNote({...newNote, observations: e.target.value})}
                  className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all h-24 resize-none"
                  placeholder="Patient presents with..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Recommendations</label>
                <textarea 
                  value={newNote.recommendations}
                  onChange={(e) => setNewNote({...newNote, recommendations: e.target.value})}
                  className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all h-24 resize-none"
                  placeholder="Implement 20-20-20 rule..."
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Follow-up Interval</label>
                  <select 
                    value={newNote.followUpInterval}
                    onChange={(e) => setNewNote({...newNote, followUpInterval: e.target.value})}
                    className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all bg-white"
                  >
                    <option>1 week</option>
                    <option>2 weeks</option>
                    <option>1 month</option>
                    <option>PRN</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Referrals</label>
                  <select 
                    value={newNote.referrals}
                    onChange={(e) => setNewNote({...newNote, referrals: e.target.value})}
                    className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all bg-white"
                  >
                    <option>None</option>
                    <option>Neurology</option>
                    <option>Neuropsychology</option>
                    <option>Vestibular Therapy</option>
                    <option>Psychology</option>
                  </select>
                </div>
              </div>
            </div>
            <div className="p-6 border-t border-slate-100 bg-slate-50 flex justify-end space-x-3">
              <button 
                onClick={() => setShowNoteModal(false)}
                className="px-6 py-3 rounded-xl font-medium text-slate-600 hover:bg-slate-200 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={handleSaveNote}
                className="px-6 py-3 rounded-xl font-medium text-white bg-blue-600 hover:bg-blue-700 transition-colors shadow-sm"
              >
                Save Note
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Dummy User icon component since it wasn't imported from lucide-react in this file
function User(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  );
}
