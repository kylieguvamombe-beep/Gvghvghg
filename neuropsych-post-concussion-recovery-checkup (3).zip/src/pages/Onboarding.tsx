import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore, PatientProfile } from '../store/useStore';
import { ArrowRight, CheckCircle2 } from 'lucide-react';

export default function Onboarding() {
  const navigate = useNavigate();
  const setPatientProfile = useStore((state) => state.setPatientProfile);
  
  const [step, setStep] = useState(1);
  const [profile, setProfile] = useState<Partial<PatientProfile>>({
    id: 'p_new',
    name: '',
    ageRange: '',
    dateOfInjury: '',
    causeOfInjury: '',
    diagnosedByClinician: false,
    medications: '',
    priorConcussions: '0',
  });

  const handleNext = () => {
    if (step < 4) {
      setStep(step + 1);
    } else {
      setPatientProfile(profile as PatientProfile);
      navigate('/patient/dashboard');
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <div className="flex-1 max-w-lg w-full mx-auto p-6 flex flex-col justify-center">
        
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-teal-600 uppercase tracking-wider">Step {step} of 4</span>
            <span className="text-xs text-slate-400">Profile Setup</span>
          </div>
          <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
            <div 
              className="bg-teal-500 h-full transition-all duration-500 ease-out"
              style={{ width: `${(step / 4) * 100}%` }}
            />
          </div>
        </div>

        <div className="flex-1">
          {step === 1 && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <h2 className="text-2xl font-semibold text-slate-900">Let's get started</h2>
              <p className="text-slate-500">We need a few details to personalize your recovery tracking.</p>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Your Name (or Initials)</label>
                  <input 
                    type="text"
                    value={profile.name}
                    onChange={(e) => setProfile({...profile, name: e.target.value})}
                    className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition-all"
                    placeholder="e.g. Alex J."
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Age Range</label>
                  <select 
                    value={profile.ageRange}
                    onChange={(e) => setProfile({...profile, ageRange: e.target.value})}
                    className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition-all bg-white"
                  >
                    <option value="">Select age range</option>
                    <option value="Under 18">Under 18</option>
                    <option value="18-24">18-24</option>
                    <option value="25-34">25-34</option>
                    <option value="35-44">35-44</option>
                    <option value="45-54">45-54</option>
                    <option value="55-64">55-64</option>
                    <option value="65+">65+</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <h2 className="text-2xl font-semibold text-slate-900">Injury Details</h2>
              <p className="text-slate-500">Tell us a bit about what happened.</p>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Date of Injury</label>
                  <input 
                    type="date"
                    value={profile.dateOfInjury}
                    onChange={(e) => setProfile({...profile, dateOfInjury: e.target.value})}
                    className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Cause of Injury</label>
                  <select 
                    value={profile.causeOfInjury}
                    onChange={(e) => setProfile({...profile, causeOfInjury: e.target.value})}
                    className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition-all bg-white"
                  >
                    <option value="">Select cause</option>
                    <option value="Sports/Recreation">Sports/Recreation</option>
                    <option value="Fall">Fall</option>
                    <option value="Motor Vehicle Accident">Motor Vehicle Accident</option>
                    <option value="Assault/Violence">Assault/Violence</option>
                    <option value="Work-related">Work-related</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <h2 className="text-2xl font-semibold text-slate-900">Medical History</h2>
              <p className="text-slate-500">This helps provide context for your recovery.</p>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Prior Concussions</label>
                  <select 
                    value={profile.priorConcussions}
                    onChange={(e) => setProfile({...profile, priorConcussions: e.target.value})}
                    className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition-all bg-white"
                  >
                    <option value="0">None</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3+">3 or more</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Current Medications (Optional)</label>
                  <input 
                    type="text"
                    value={profile.medications}
                    onChange={(e) => setProfile({...profile, medications: e.target.value})}
                    className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition-all"
                    placeholder="e.g. Tylenol, none"
                  />
                </div>
                <div className="flex items-center space-x-3 pt-2">
                  <input 
                    type="checkbox"
                    id="diagnosed"
                    checked={profile.diagnosedByClinician}
                    onChange={(e) => setProfile({...profile, diagnosedByClinician: e.target.checked})}
                    className="w-5 h-5 text-teal-600 rounded border-slate-300 focus:ring-teal-500"
                  />
                  <label htmlFor="diagnosed" className="text-sm text-slate-700">
                    I have been diagnosed by a medical professional
                  </label>
                </div>
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 text-center">
              <div className="w-20 h-20 bg-teal-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle2 className="w-10 h-10 text-teal-600" />
              </div>
              <h2 className="text-2xl font-semibold text-slate-900">You're all set!</h2>
              <p className="text-slate-500">
                Your profile is ready. We'll now take you to your dashboard where you can start your first recovery check-up.
              </p>
              <div className="p-4 bg-slate-50 rounded-2xl text-sm text-slate-600 text-left border border-slate-100">
                <strong>Privacy Note:</strong> Your health data must be handled carefully. This app stores your data securely. You can export it at any time to share with your healthcare provider.
              </div>
            </div>
          )}
        </div>

        <div className="pt-8">
          <button
            onClick={handleNext}
            className="w-full bg-teal-600 hover:bg-teal-700 text-white font-medium py-4 px-6 rounded-2xl flex items-center justify-center transition-colors shadow-sm"
          >
            {step === 4 ? 'Go to Dashboard' : 'Continue'}
            {step < 4 && <ArrowRight className="w-5 h-5 ml-2" />}
          </button>
        </div>
      </div>
    </div>
  );
}
