import { useNavigate } from 'react-router-dom';
import { useStore } from '../store/useStore';
import { Brain, Stethoscope, User } from 'lucide-react';

export default function Welcome() {
  const navigate = useNavigate();
  const setRole = useStore((state) => state.setRole);

  const handleSelectRole = (role: 'patient' | 'clinician') => {
    setRole(role);
    if (role === 'patient') {
      navigate('/onboarding');
    } else {
      navigate('/clinician/dashboard');
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gradient-to-b from-teal-50 to-slate-50">
      <div className="max-w-md w-full bg-white rounded-3xl shadow-xl overflow-hidden">
        <div className="p-8 text-center bg-teal-600 text-white">
          <Brain className="w-16 h-16 mx-auto mb-4 opacity-90" />
          <h1 className="text-2xl font-semibold tracking-tight mb-2">Neuropsych Recovery</h1>
          <p className="text-teal-100 text-sm">Post-Concussion Checkup & Monitoring</p>
        </div>
        
        <div className="p-8 space-y-6">
          <div className="text-center space-y-2">
            <h2 className="text-lg font-medium text-slate-800">Welcome</h2>
            <p className="text-sm text-slate-500">
              This app helps you and your healthcare team track your recovery over time. 
              Please select how you will be using this app today.
            </p>
          </div>

          <div className="space-y-4">
            <button
              onClick={() => handleSelectRole('patient')}
              className="w-full flex items-center p-4 border-2 border-slate-100 rounded-2xl hover:border-teal-500 hover:bg-teal-50 transition-all group"
            >
              <div className="w-12 h-12 bg-teal-100 text-teal-600 rounded-full flex items-center justify-center group-hover:bg-teal-500 group-hover:text-white transition-colors">
                <User className="w-6 h-6" />
              </div>
              <div className="ml-4 text-left">
                <div className="font-medium text-slate-900">Patient or Caregiver</div>
                <div className="text-xs text-slate-500">Track my own or a loved one's recovery</div>
              </div>
            </button>

            <button
              onClick={() => handleSelectRole('clinician')}
              className="w-full flex items-center p-4 border-2 border-slate-100 rounded-2xl hover:border-blue-500 hover:bg-blue-50 transition-all group"
            >
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center group-hover:bg-blue-500 group-hover:text-white transition-colors">
                <Stethoscope className="w-6 h-6" />
              </div>
              <div className="ml-4 text-left">
                <div className="font-medium text-slate-900">Clinician or Trainee</div>
                <div className="text-xs text-slate-500">Review patient data and trends</div>
              </div>
            </button>
          </div>
          
          <div className="text-xs text-slate-400 text-center mt-8 px-4">
            This tool does not replace a doctor, diagnose concussions, or provide emergency care.
          </div>
        </div>
      </div>
    </div>
  );
}
