import { useNavigate } from 'react-router-dom';
import { useStore } from '../store/useStore';
import { Users, Search, Filter, ChevronRight, AlertCircle, CheckCircle2, Clock } from 'lucide-react';

export default function ClinicianDashboard() {
  const navigate = useNavigate();
  const patients = useStore((state) => state.mockPatients);
  const checkups = useStore((state) => state.checkups);

  const getLatestCheckup = (patientId: string) => {
    const patientCheckups = checkups.filter(c => c.patientId === patientId);
    return patientCheckups.length > 0 ? patientCheckups[patientCheckups.length - 1] : null;
  };

  const getStatusIcon = (category: string | undefined) => {
    switch (category) {
      case 'Improving': return <CheckCircle2 className="w-5 h-5 text-emerald-500" />;
      case 'Stable': return <CheckCircle2 className="w-5 h-5 text-blue-500" />;
      case 'Delayed Recovery': return <Clock className="w-5 h-5 text-amber-500" />;
      case 'Needs Medical Review': return <AlertCircle className="w-5 h-5 text-rose-500" />;
      default: return <CheckCircle2 className="w-5 h-5 text-slate-300" />;
    }
  };

  const getStatusColor = (category: string | undefined) => {
    switch (category) {
      case 'Improving': return 'bg-emerald-50 text-emerald-700 border-emerald-100';
      case 'Stable': return 'bg-blue-50 text-blue-700 border-blue-100';
      case 'Delayed Recovery': return 'bg-amber-50 text-amber-700 border-amber-100';
      case 'Needs Medical Review': return 'bg-rose-50 text-rose-700 border-rose-100';
      default: return 'bg-slate-50 text-slate-500 border-slate-100';
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-blue-700 text-white p-6 pt-12 pb-24 rounded-b-[2.5rem] shadow-md">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-semibold">Clinician Portal</h1>
            <p className="text-blue-200 text-sm opacity-90">Patient Overview</p>
          </div>
          <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
            <Users className="w-6 h-6 text-white" />
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative mt-4">
          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-blue-300" />
          </div>
          <input
            type="text"
            className="block w-full pl-11 pr-4 py-3 border-0 rounded-2xl leading-5 bg-white/10 text-white placeholder-blue-200 focus:outline-none focus:bg-white/20 focus:ring-2 focus:ring-white/50 transition-colors sm:text-sm backdrop-blur-md"
            placeholder="Search patients..."
          />
          <div className="absolute inset-y-0 right-0 pr-2 flex items-center">
            <button className="p-2 text-blue-200 hover:text-white transition-colors">
              <Filter className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Patient List */}
      <div className="px-6 -mt-16 space-y-4 pb-20">
        <div className="flex justify-between items-center px-2 mb-2">
          <h2 className="text-sm font-semibold text-slate-600 uppercase tracking-wider">Active Patients ({patients.length})</h2>
        </div>

        {patients.map(patient => {
          const latest = getLatestCheckup(patient.id);
          const status = latest?.recoveryCategory || 'No Data';
          
          return (
            <div 
              key={patient.id}
              onClick={() => navigate(`/clinician/patient/${patient.id}`)}
              className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100 hover:shadow-md transition-all cursor-pointer group"
            >
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 font-semibold text-lg border border-slate-200">
                    {patient.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900">{patient.name}</h3>
                    <p className="text-xs text-slate-500">Injured: {new Date(patient.dateOfInjury).toLocaleDateString()}</p>
                  </div>
                </div>
                <div className="p-2 bg-slate-50 rounded-full group-hover:bg-blue-50 transition-colors">
                  <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-blue-600" />
                </div>
              </div>
              
              <div className="flex items-center justify-between pt-4 border-t border-slate-50">
                <div className={`flex items-center px-3 py-1.5 rounded-lg border text-xs font-medium ${getStatusColor(status)}`}>
                  {getStatusIcon(status)}
                  <span className="ml-2">{status}</span>
                </div>
                <div className="text-xs text-slate-400 font-medium">
                  {latest ? `Last log: ${new Date(latest.date).toLocaleDateString()}` : 'No logs yet'}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
