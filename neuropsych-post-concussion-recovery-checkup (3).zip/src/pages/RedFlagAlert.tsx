import { useNavigate } from 'react-router-dom';
import { AlertTriangle, Phone, MapPin } from 'lucide-react';

export default function RedFlagAlert() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-rose-50 flex flex-col items-center justify-center p-6 text-center">
      <div className="max-w-md w-full bg-white rounded-3xl shadow-xl overflow-hidden border-2 border-rose-200">
        <div className="bg-rose-600 p-8 text-white flex flex-col items-center">
          <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mb-6 animate-pulse">
            <AlertTriangle className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight mb-2">Urgent Medical Attention Recommended</h1>
        </div>
        
        <div className="p-8 space-y-6">
          <p className="text-slate-700 font-medium text-lg leading-relaxed">
            You reported symptoms that require immediate medical review.
          </p>
          <p className="text-slate-500 text-sm">
            Symptoms like worsening headache, repeated vomiting, or new confusion can be signs of a more serious issue.
          </p>

          <div className="space-y-4 pt-4">
            <a href="tel:911" className="w-full flex items-center justify-center p-4 bg-rose-600 hover:bg-rose-700 text-white rounded-2xl font-semibold transition-colors shadow-md">
              <Phone className="w-5 h-5 mr-3" />
              Call Emergency Services (911)
            </a>
            
            <button className="w-full flex items-center justify-center p-4 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-2xl font-medium transition-colors border border-slate-200">
              <MapPin className="w-5 h-5 mr-3 text-slate-500" />
              Find Nearest Urgent Care
            </button>
          </div>
        </div>
        
        <div className="bg-slate-50 p-6 border-t border-slate-100">
          <button 
            onClick={() => navigate('/patient/dashboard')}
            className="text-sm font-medium text-slate-500 hover:text-slate-800 transition-colors"
          >
            Return to Dashboard
          </button>
        </div>
      </div>
    </div>
  );
}
