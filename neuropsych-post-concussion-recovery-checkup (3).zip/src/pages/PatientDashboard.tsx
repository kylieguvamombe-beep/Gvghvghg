import { useNavigate } from 'react-router-dom';
import { useStore } from '../store/useStore';
import { Activity, AlertCircle, Calendar, ChevronRight, FileText, User } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function PatientDashboard() {
  const navigate = useNavigate();
  const profile = useStore((state) => state.patientProfile);
  const checkups = useStore((state) => state.checkups).filter(c => c.patientId === profile?.id);

  const latestCheckup = checkups.length > 0 ? checkups[checkups.length - 1] : null;

  const chartData = checkups.map(c => ({
    date: new Date(c.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    physical: (c.headache + c.dizziness + c.nausea + c.lightSensitivity + c.noiseSensitivity + c.fatigue + c.balance) / 7,
    cognitive: (c.memory + c.attention + c.processingSpeed + c.wordFinding + c.mentalFatigue) / 5,
  }));

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      {/* Header */}
      <div className="bg-teal-600 text-white p-6 pt-12 rounded-b-3xl shadow-md">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-semibold">Hello, {profile?.name || 'Friend'}</h1>
            <p className="text-teal-100 text-sm opacity-90">Your Recovery Dashboard</p>
          </div>
          <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
            <User className="w-6 h-6 text-white" />
          </div>
        </div>

        {/* Status Card */}
        <div className="bg-white rounded-2xl p-5 text-slate-800 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-teal-50 rounded-full -mr-16 -mt-16 opacity-50"></div>
          <div className="relative z-10">
            <div className="flex items-center space-x-2 mb-1">
              <Activity className="w-5 h-5 text-teal-500" />
              <h2 className="font-medium text-sm text-slate-500 uppercase tracking-wider">Current Status</h2>
            </div>
            <div className="text-2xl font-bold text-slate-900 mb-2">
              {latestCheckup ? latestCheckup.recoveryCategory : 'No Data Yet'}
            </div>
            <p className="text-sm text-slate-600">
              {latestCheckup 
                ? `Last check-in was on ${new Date(latestCheckup.date).toLocaleDateString()}`
                : 'Complete your first check-up to establish a baseline.'}
            </p>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Action Button */}
        <button
          onClick={() => navigate('/patient/checkup')}
          className="w-full bg-teal-600 hover:bg-teal-700 text-white font-medium py-4 px-6 rounded-2xl flex items-center justify-between transition-colors shadow-sm group"
        >
          <div className="flex items-center">
            <Calendar className="w-5 h-5 mr-3 opacity-90" />
            <span>Start Recovery Check-up</span>
          </div>
          <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
        </button>

        {/* Trend Chart */}
        {checkups.length > 0 && (
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
            <div className="flex justify-between items-center mb-6">
              <h3 className="font-semibold text-slate-900">Symptom Trends</h3>
              <span className="text-xs font-medium bg-slate-100 text-slate-600 px-2 py-1 rounded-md">Last {checkups.length} logs</span>
            </div>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} dy={10} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} domain={[0, 5]} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                    labelStyle={{ color: '#64748b', marginBottom: '4px' }}
                  />
                  <Line type="monotone" dataKey="physical" name="Physical (Avg)" stroke="#0ea5e9" strokeWidth={3} dot={{ r: 4, strokeWidth: 2 }} activeDot={{ r: 6 }} />
                  <Line type="monotone" dataKey="cognitive" name="Cognitive (Avg)" stroke="#f59e0b" strokeWidth={3} dot={{ r: 4, strokeWidth: 2 }} activeDot={{ r: 6 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <div className="flex justify-center space-x-6 mt-4 text-xs text-slate-500">
              <div className="flex items-center"><div className="w-3 h-3 rounded-full bg-sky-500 mr-2"></div>Physical</div>
              <div className="flex items-center"><div className="w-3 h-3 rounded-full bg-amber-500 mr-2"></div>Cognitive</div>
            </div>
          </div>
        )}

        {/* Resources */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
          <h3 className="font-semibold text-slate-900 mb-4">Resources</h3>
          <div className="space-y-3">
            <div className="flex items-center p-3 hover:bg-slate-50 rounded-xl cursor-pointer transition-colors border border-transparent hover:border-slate-100">
              <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center mr-4">
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <div className="text-sm font-medium text-slate-900">Return to Learn Protocol</div>
                <div className="text-xs text-slate-500">Guidelines for school</div>
              </div>
            </div>
            <div className="flex items-center p-3 hover:bg-slate-50 rounded-xl cursor-pointer transition-colors border border-transparent hover:border-slate-100">
              <div className="w-10 h-10 bg-rose-50 text-rose-600 rounded-lg flex items-center justify-center mr-4">
                <AlertCircle className="w-5 h-5" />
              </div>
              <div>
                <div className="text-sm font-medium text-slate-900">When to seek urgent care</div>
                <div className="text-xs text-slate-500">Red flag symptoms</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
