import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore, Checkup } from '../store/useStore';
import { ArrowLeft, ArrowRight, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const questions = [
  // Physical
  { id: 'headache', category: 'Physical', text: 'How severe is your headache today?', type: 'scale' },
  { id: 'dizziness', category: 'Physical', text: 'How dizzy do you feel?', type: 'scale' },
  { id: 'nausea', category: 'Physical', text: 'Are you experiencing nausea?', type: 'scale' },
  { id: 'lightSensitivity', category: 'Physical', text: 'How sensitive are you to light?', type: 'scale' },
  { id: 'noiseSensitivity', category: 'Physical', text: 'How sensitive are you to noise?', type: 'scale' },
  { id: 'fatigue', category: 'Physical', text: 'How physically fatigued are you?', type: 'scale' },
  { id: 'balance', category: 'Physical', text: 'Are you having balance issues?', type: 'scale' },
  
  // Cognitive
  { id: 'memory', category: 'Cognitive', text: 'Are you having trouble remembering things?', type: 'scale' },
  { id: 'attention', category: 'Cognitive', text: 'How difficult is it to concentrate?', type: 'scale' },
  { id: 'processingSpeed', category: 'Cognitive', text: 'Does your thinking feel slowed down?', type: 'scale' },
  { id: 'wordFinding', category: 'Cognitive', text: 'Are you struggling to find the right words?', type: 'scale' },
  { id: 'mentalFatigue', category: 'Cognitive', text: 'How mentally exhausted do you feel after tasks?', type: 'scale' },
  
  // Mood
  { id: 'frustration', category: 'Mood', text: 'How easily frustrated are you getting?', type: 'scale' },
  { id: 'lowMood', category: 'Mood', text: 'Are you feeling sad or low?', type: 'scale' },
  { id: 'anxiety', category: 'Mood', text: 'How anxious or nervous do you feel?', type: 'scale' },
  { id: 'irritability', category: 'Mood', text: 'Are you feeling more irritable than usual?', type: 'scale' },
  { id: 'withdrawal', category: 'Mood', text: 'Are you withdrawing from social interactions?', type: 'scale' },
  
  // Functional
  { id: 'schoolWork', category: 'Functional', text: 'How difficult is school or work right now?', type: 'scale' },
  { id: 'screenTime', category: 'Functional', text: 'How difficult is it to tolerate screens (phone, TV)?', type: 'scale' },
  
  // Red Flags
  { id: 'worseningHeadache', category: 'Safety', text: 'Is your headache getting significantly worse?', type: 'boolean' },
  { id: 'repeatedVomiting', category: 'Safety', text: 'Have you vomited repeatedly today?', type: 'boolean' },
  { id: 'newConfusion', category: 'Safety', text: 'Are you experiencing new or worsening confusion?', type: 'boolean' },
  { id: 'severeImbalance', category: 'Safety', text: 'Are you unable to walk without losing balance?', type: 'boolean' },
];

export default function CheckupFlow() {
  const navigate = useNavigate();
  const profile = useStore((state) => state.patientProfile);
  const addCheckup = useStore((state) => state.addCheckup);

  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number | boolean>>({});
  const [direction, setDirection] = useState(1);

  const currentQuestion = questions[currentIndex];
  const progress = ((currentIndex + 1) / questions.length) * 100;

  const handleAnswer = (value: number | boolean) => {
    setAnswers({ ...answers, [currentQuestion.id]: value });
    
    // Check for red flags immediately
    if (currentQuestion.category === 'Safety' && value === true) {
      navigate('/patient/red-flag');
      return;
    }

    if (currentIndex < questions.length - 1) {
      setDirection(1);
      setCurrentIndex(currentIndex + 1);
    } else {
      finishCheckup();
    }
  };

  const handleBack = () => {
    if (currentIndex > 0) {
      setDirection(-1);
      setCurrentIndex(currentIndex - 1);
    } else {
      navigate('/patient/dashboard');
    }
  };

  const finishCheckup = () => {
    // Calculate recovery category based on mock logic
    const totalPhysical = (answers.headache as number || 0) + (answers.fatigue as number || 0);
    const category = totalPhysical > 6 ? 'Delayed Recovery' : 'Improving';

    const checkup: Checkup = {
      id: `c_${Date.now()}`,
      patientId: profile?.id || 'p_new',
      date: new Date().toISOString(),
      
      headache: answers.headache as number || 0,
      dizziness: answers.dizziness as number || 0,
      nausea: answers.nausea as number || 0,
      lightSensitivity: answers.lightSensitivity as number || 0,
      noiseSensitivity: answers.noiseSensitivity as number || 0,
      sleepChanges: 0,
      fatigue: answers.fatigue as number || 0,
      balance: answers.balance as number || 0,

      memory: answers.memory as number || 0,
      attention: answers.attention as number || 0,
      processingSpeed: answers.processingSpeed as number || 0,
      wordFinding: answers.wordFinding as number || 0,
      mentalFatigue: answers.mentalFatigue as number || 0,

      frustration: answers.frustration as number || 0,
      lowMood: answers.lowMood as number || 0,
      anxiety: answers.anxiety as number || 0,
      irritability: answers.irritability as number || 0,
      withdrawal: answers.withdrawal as number || 0,

      schoolWork: answers.schoolWork as number || 0,
      exercise: 0,
      driving: 0,
      reading: 0,
      screenTime: answers.screenTime as number || 0,
      socialActivity: 0,

      worseningHeadache: answers.worseningHeadache as boolean || false,
      repeatedVomiting: answers.repeatedVomiting as boolean || false,
      seizures: false,
      fainting: false,
      newConfusion: answers.newConfusion as boolean || false,
      severeImbalance: answers.severeImbalance as boolean || false,
      suicidalThinking: false,

      recoveryCategory: category,
    };

    addCheckup(checkup);
    navigate('/patient/summary', { state: { category } });
  };

  const variants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 100 : -100,
      opacity: 0
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 100 : -100,
      opacity: 0
    })
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header */}
      <div className="bg-white p-4 shadow-sm z-10">
        <div className="flex items-center justify-between max-w-lg mx-auto">
          <button onClick={handleBack} className="p-2 -ml-2 text-slate-500 hover:text-slate-800 transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div className="text-sm font-medium text-slate-500 uppercase tracking-widest">
            {currentQuestion.category}
          </div>
          <div className="w-10"></div> {/* Spacer for centering */}
        </div>
        
        {/* Progress Bar */}
        <div className="max-w-lg mx-auto mt-4">
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
            <div 
              className="bg-teal-500 h-full transition-all duration-300 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </div>

      {/* Question Area */}
      <div className="flex-1 relative overflow-hidden flex items-center justify-center p-6">
        <AnimatePresence initial={false} custom={direction} mode="wait">
          <motion.div
            key={currentIndex}
            custom={direction}
            variants={variants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="w-full max-w-lg absolute"
          >
            <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100 text-center">
              <h2 className="text-2xl font-medium text-slate-800 mb-8 leading-tight">
                {currentQuestion.text}
              </h2>

              {currentQuestion.type === 'scale' ? (
                <div className="space-y-4">
                  <div className="flex justify-between text-xs font-semibold text-slate-400 uppercase tracking-wider px-2 mb-2">
                    <span>None</span>
                    <span>Severe</span>
                  </div>
                  <div className="grid grid-cols-6 gap-2">
                    {[0, 1, 2, 3, 4, 5].map((num) => (
                      <button
                        key={num}
                        onClick={() => handleAnswer(num)}
                        className={`
                          aspect-square rounded-2xl text-lg font-medium transition-all
                          ${answers[currentQuestion.id] === num 
                            ? 'bg-teal-600 text-white shadow-md scale-105' 
                            : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-100'}
                        `}
                      >
                        {num}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-4">
                  <button
                    onClick={() => handleAnswer(false)}
                    className={`
                      py-4 rounded-2xl text-lg font-medium transition-all
                      ${answers[currentQuestion.id] === false 
                        ? 'bg-teal-600 text-white shadow-md' 
                        : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-100'}
                    `}
                  >
                    No
                  </button>
                  <button
                    onClick={() => handleAnswer(true)}
                    className={`
                      py-4 rounded-2xl text-lg font-medium transition-all
                      ${answers[currentQuestion.id] === true 
                        ? 'bg-rose-600 text-white shadow-md' 
                        : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-100'}
                    `}
                  >
                    Yes
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
